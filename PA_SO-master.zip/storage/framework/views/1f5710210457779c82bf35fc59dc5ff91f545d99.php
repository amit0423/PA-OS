<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
	<!--<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0"> -->

    <!-- Styles -->
    <link href="<?php echo e(asset('/css/app.css')); ?>" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="/assets/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="/assets/css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="/assets/css/select2.min.css">
	<link rel="stylesheet" type="text/css" href="/assets/css/bootstrap-datetimepicker.min.css">
    <!-- ===== Bootstrap CSS ===== -->
    <link rel="stylesheet" type="text/css" href="/assets/css/bootstrap.min.css">
    <!-- ===== Custom CSS ===== -->
    <link rel="stylesheet" type="text/css" href="/assets/css/style.css">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Background image -->
    <style>
    body, html {
        height: 100%;
        margin: 0;
    }

    .bg {
        /* The image used */
        background-image: url("/assets/img/background.jpg");

        /* Full height */
        height: 100%; 

        /* Center and scale the image nicely */
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
    }
    </style>

</head>
<body>
    <div class="bg" id="app">
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse" aria-expanded="false">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

	                <div class="header-left">
	                    <a href="/" class="logo">
							<img src="/assets/img/logo.png" width="175" height="50" alt="logo">
						</a>
	                </div>
					
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        &nbsp;
                    </ul>
					<!-- Center Of Navbar -->
					<ul><a class="navbar-brand" href="<?php echo e(url('/')); ?>"> <?php echo e(config('app.longname', 'Laravel')); ?></a></ul>	
                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li><a href="<?php echo e(route('login')); ?>"><?php echo app('translator')->getFromJson('Login'); ?></a></li>
                            <li><a href="<?php echo e(route('register')); ?>"><?php echo app('translator')->getFromJson('Register'); ?></a></li>
                        <?php else: ?>
                            <li class="dropdown">
								<!--  <span class="user-img"><img class="img-circle" src="/assets/img/user.jpg" width="40" alt=<?php echo e(Auth::user()->name); ?>> -->
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" aria-haspopup="true" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            <?php echo app('translator')->getFromJson('Logout'); ?>
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <div class="sidebar-overlay" data-reff="#sidebar"></div>

    <!-- Scripts -->
    <!-- <script src="<?php echo e(asset('js/app.js')); ?>"></script> -->
	<script type="text/javascript" src="/assets/js/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script type="text/javascript" src="/assets/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="/assets/js/jquery.slimscroll.js"></script>
	<script type="text/javascript" src="/assets/plugins/morris/morris.min.js"></script>
	<script type="text/javascript" src="/assets/plugins/raphael/raphael-min.js"></script>
	<script type="text/javascript" src="/assets/js/app.js"></script>
	
</body>
</html>
