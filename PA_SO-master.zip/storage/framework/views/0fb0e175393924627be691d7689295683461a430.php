            <!-- ===== Top Navigation bar for users ===== -->
            <!-- == Logo == -->
            <div class="header-left">
                <a href="/" class="logo">
                    <img src="/assets/img/logo.png" width="175" height="50" alt="logo">
                </a>
            </div>
            <!-- == Title == -->
            <div class="page-title-box pull-left">
                <h3><?php echo e(config('app.longname', 'Laravel')); ?></h3>
            </div>
            <!-- == Bars for sidebar == -->
            <a id="mobile_btn" class="mobile_btn pull-left" href="#sidebar"><i class="fa fa-bars" aria-hidden="true"></i></a>
            <!-- == Right side == -->
            <ul class="nav navbar-nav navbar-right user-menu pull-right">
                <!-- == Notifications == -->
                <li class="dropdown hidden-xs">
                    <?php if(count(Auth::user()->unreadNotifications) === 0): ?>
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bell-o"></i></a>
                    <?php else: ?>
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bell-o"></i> <span class="badge bg-danger pull-right"><?php echo e(count(Auth::user()->unreadNotifications)); ?></span></a>
                    <?php endif; ?>
                    <div class="dropdown-menu notifications">
                        <div class="topnav-dropdown-header">
                            <span><?php echo app('translator')->getFromJson('Notifications'); ?></span>
                        </div>
                        <?php if(count(Auth::user()->unreadNotifications)): ?>
                            <div class="chat-header">
                                <a href="<?php echo e(route('markAllRead')); ?>"><span><?php echo app('translator')->getFromJson('Mark all as Read'); ?></span></a>
                            </div>
                        <?php endif; ?>
                        <div class="drop-scroll">
                            <ul class="media-list">
                                <?php $__empty_1 = true; $__currentLoopData = Auth::user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <li class="media notification-message">    
                                        <a href="notifications">
                                            <div class="media-body">
                                                <p class="m-0 noti-details"><i class="fa fa-envelope"></i><span class="noti-title"> <?php echo e($notification->data['title']); ?></span> <?php echo e($notification->data['detail']); ?></p>
                                                <p class="m-0"><span class="notification-time"><?php echo e(date('d/M/y H:i',strtotime($notification->created_at))); ?></span></p>
                                            </div>
                                        </a>
                                    <!-- <?php echo $__env->make('layouts.partials.notifications.'.snake_case(class_basename($notification->type)), ['notificationdata' => $notification->data['detail']], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>== -->
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <li class="media notification-message">
                                        <div class="media-body">
                                        <p class="m-0 noti-details"><span class="noti-title"><br>&nbsp <?php echo app('translator')->getFromJson('No unread notifications'); ?></span></p>
                                        </div>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                        <div class="topnav-dropdown-footer">
                            <a href="notifications-all"><?php echo app('translator')->getFromJson('View all Notifications'); ?></a>
                        </div>
                    </div>
                </li>
                <!-- == User Name == -->
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle user-link" data-toggle="dropdown" title="User">
                        <span class="status online"></span></span>
                        <span><?php echo e(Auth::user()->name); ?></span>
                        <i class="caret"></i>
                    </a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                                <?php echo app('translator')->getFromJson('Logout'); ?>
                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo e(csrf_field()); ?>

                            </form>
                        </li>
                    </ul>
				</li>
            </ul>
            <div class="dropdown mobile-user-menu pull-right">
                <!-- == Dropdown menu == -->
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                <ul class="dropdown-menu pull-right">
                    <li>
                        <a href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                            <?php echo app('translator')->getFromJson('Logout'); ?>
                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </li>
                </ul>
            </div>
<!-- ===== Top Navigation bar for users-End ===== -->