<?php $__env->startSection('content'); ?>
            <div class="content container-fluid">
				<div class="row">
					<div class="col-xs-4">
						<h4 class="page-title"><?php echo e($title); ?></h4>
					</div>
					<div class="col-xs-8 text-right m-b-30">
                        <ul class="nav navbar-nav pull-right chat-menu">
                            <li class="dropdown">
                                <a href="" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-cog"></i></a>
                                <ul class="dropdown-menu">
                                    <li><a href="notifications-unread"><?php echo app('translator')->getFromJson('Unread notifications'); ?></a></li>
                                    <li><a href="notifications-all"><?php echo app('translator')->getFromJson('All notifications'); ?></a></li>
                                </ul>
                            </li>
                        </ul>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="table-responsive">
							<table id="myTable" class="table table-striped table-hover custom-table datatable">
								<thead>
									<tr>
										<th style="width:12%"><?php echo app('translator')->getFromJson('Title'); ?></th>
										<th><?php echo app('translator')->getFromJson('Description'); ?></th>
										<th><?php echo app('translator')->getFromJson('Creation date'); ?></th>
										<th><?php echo app('translator')->getFromJson('Status'); ?></th>
										<th class="text-right"><?php echo app('translator')->getFromJson('Action'); ?></th>
									</tr>
								</thead>
								<tbody>
								<?php switch($filterread):
									case ('unread'): ?>
										<?php if(count(Auth::user()->unreadNotifications)>0): ?>
											<?php $__currentLoopData = Auth::user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<tr>
													<td><b><?php echo e($notif->data['title']); ?></b></td>
													<td><b><?php echo e($notif->data['detail']); ?></b></td>
													<td value=<?php echo e($notif->created_at); ?>> <?php echo e(date_format($notif->created_at, "Y/m/d")); ?></td>
													<?php if(is_null($notif->read_at)): ?>
														<?php ($label = 'info'); ?>
														<td><span class="label label-info-border">Unread</span></td>
														<td class="text-right">
															<div class="dropdown">
																<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
																<ul class="dropdown-menu pull-right">
																	<li><a href="notification-markasread-<?php echo e($notif->id); ?>" name="markasread"><i class="fa fa-eye m-r-5"> </i>Mark as read</a></li>
																	<li><a href="notification-delete-<?php echo e($notif->id); ?>" name="delete"><i class="fa fa-ban m-r-5"> </i><?php echo app('translator')->getFromJson('Delete'); ?></a></li>
																</ul>
															</div>
														</td>
													<?php else: ?>
														<td><span class="label label-success-border">Read</span></td>
														<td class="text-right">
															<div class="dropdown">
																<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
																<ul class="dropdown-menu pull-right">
																	<li><a href="notification-markasunread-<?php echo e($notif->id); ?>" name="markasunread"><i class="fa fa-eye-slash m-r-5"> </i>Mark as unread</a></li>
																	<li><a href="notification-delete-<?php echo e($notif->id); ?>" name="delete"><i class="fa fa-ban m-r-5"> </i><?php echo app('translator')->getFromJson('Delete'); ?></a></li>
																</ul>
															</div>
														</td>
													<?php endif; ?>
												</tr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php endif; ?>
										<?php break; ?>

									<?php case ('all'): ?>
										<?php if(count(Auth::user()->Notifications)>0): ?>
											<?php $__currentLoopData = Auth::user()->Notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<tr>
												<?php if(is_null($notif->read_at)): ?>
													<td><b><?php echo e($notif->data['title']); ?></b></td>
													<td><b><?php echo e($notif->data['detail']); ?></b></td>
													<?php else: ?>
												    <td><?php echo e($notif->data['title']); ?></td>
													<td><?php echo e($notif->data['detail']); ?></td>
							<?php endif; ?>
													<td value=<?php echo e($notif->created_at); ?>> <?php echo e(date_format($notif->created_at, "Y/m/d")); ?></td>
													<?php if(is_null($notif->read_at)): ?>
														<?php ($label = 'info'); ?>
														<td><span class="label label-info-border">Unread</span></td>
														<td class="text-right">
															<div class="dropdown">
																<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
																<ul class="dropdown-menu pull-right">
																	<li><a href="notification-markasread-<?php echo e($notif->id); ?>" name="markasread"><i class="fa fa-eye m-r-5"> </i><?php echo app('translator')->getFromJson('Mark as read'); ?></a></li>
																	<li><a href="notification-delete-<?php echo e($notif->id); ?>" name="delete"><i class="fa fa-ban m-r-5"> </i><?php echo app('translator')->getFromJson('Delete'); ?></a></li>
																</ul>
															</div>
														</td>
													<?php else: ?>
												
													<td value=<?php echo e($notif->created_at); ?>> <?php echo e(date_format($notif->created_at, "Y/m/d")); ?></td>
														<td><span class="label label-success-border">Read</span></td>
														<td class="text-right">
															<div class="dropdown">
																<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
																<ul class="dropdown-menu pull-right">
																	<li><a href="notification-markasunread-<?php echo e($notif->id); ?>" name="markasunread"><i class="fa fa-eye-slash m-r-5"> </i><?php echo app('translator')->getFromJson('Mark as unread'); ?></a></li>
																	<li><a href="notification-delete-<?php echo e($notif->id); ?>" name="delete"><i class="fa fa-ban m-r-5"> </i><?php echo app('translator')->getFromJson('Delete'); ?></a></li>
																</ul>
															</div>
														</td>
													<?php endif; ?>
												</tr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php endif; ?>
										<?php break; ?>
								<?php endswitch; ?>

								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customscript'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>