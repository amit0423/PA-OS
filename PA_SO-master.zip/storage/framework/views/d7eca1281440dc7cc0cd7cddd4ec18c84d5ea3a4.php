
 <!-- ===== Left-Sidebar ===== -->
    <aside class="sidebar">
        <div class="sidebar-menu"> <!--<div class="scroll-sidebar" "sidebar-inner slimscroll"> -->
            <div class="user-profile">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4><?php echo e(Auth::user()->name); ?></h4>
                        <?php if(!Auth::user()->on_behalf_name==Null): ?>
                            <h5>(pour <?php echo e(Auth::user()->on_behalf_name); ?>)</h5>
                        <?php endif; ?>
                        <?php switch(Auth::user()->is_permission):
                            case (1): ?>
                                <div class="staff-id"><?php echo app('translator')->getFromJson('Administrator'); ?></div>
                                <?php break; ?>
                            <?php case (2): ?>
                                <div class="staff-id"><?php echo app('translator')->getFromJson('Super user'); ?></div>
                                <?php break; ?>
                        <?php endswitch; ?>
                    </div>
                    <div class="panel-body">
                        <img src=<?php echo e(Auth::user()->img_src); ?> width="80" alt=<?php echo e(Auth::user()->name); ?> class="img-circle">
                    </div>
                    <div class="panel-footer">
                        <div class="staff-id"><?php echo e(Auth::user()->group); ?></div>
                        <?php if(Auth::user()->assign_right===1): ?>
                            <small class="text-muted"><?php echo app('translator')->getFromJson('Can assign'); ?> <?php echo app('translator')->getFromJson('Projects'); ?></small>
                        <?php endif; ?>
                        <br>
                        <?php if(Auth::user()->delegate_right===1): ?>
                            <small class="text-muted"><?php echo app('translator')->getFromJson('Can delegate'); ?> <?php echo app('translator')->getFromJson('Projects'); ?></small>
                        <?php endif; ?>                       
                    </div>
                </div>
            </div>
            <nav class="sidebar-nav">
                <ul id="side-menu">
                    <li class="submenu">
                        <?php if(Request::is('*home*') || Request::is('/')): ?>
                        <a href="home"><span style="font-weight:bold"><i class="fa fa-pie-chart"></i> <?php echo app('translator')->getFromJson('Dashboard'); ?></span></a>
                        <?php else: ?>
                        <a href="home"><i class="fa fa-pie-chart"></i> <?php echo app('translator')->getFromJson('Dashboard'); ?></a>
                        <?php endif; ?>
                    </li>
                    <li class="submenu">
                        <?php if(Request::is('*project*')): ?>
                        <a href="projects-index"><span style="font-weight:bold"><i class="fa fa-briefcase"></i> <?php echo app('translator')->getFromJson('Projects'); ?></span></a>
                        <?php else: ?>
                        <a href="projects-index"><i class="fa fa-briefcase"></i> <?php echo app('translator')->getFromJson('Projects'); ?></a>
                        <?php endif; ?>
                    </li>
                    <li class="submenu">
                        <?php if(Request::is('*task*')): ?>
                        <a href="tasks-index"><span style="font-weight:bold"><i class="fa fa-clipboard"></i> <?php echo app('translator')->getFromJson('Tasks'); ?></span></a>
                        <?php else: ?>
                        <a href="tasks-index"><i class="fa fa-clipboard"></i> <?php echo app('translator')->getFromJson('Tasks'); ?></a>
                        <?php endif; ?>
                    </li>
                    <li class="submenu">
                        <?php if(Request::is('*notification*')): ?>
                        <a href="notifications-unread"><span style="font-weight:bold"><i class="fa fa-sticky-note"></i> <?php echo app('translator')->getFromJson('Notifications'); ?></span></a>
                        <?php else: ?>
                        <a href="notifications-unread"><i class="fa fa-sticky-note"></i> <?php echo app('translator')->getFromJson('Notifications'); ?></a>
                        <?php endif; ?>
                    </li>
                    <?php if(Auth::user()->is_permission===1): ?>
                        <li class="submenu">
                            <a href="#" data-toggle="collapse" data-target="#demo"><i class="fa fa-cog"></i> <?php echo app('translator')->getFromJson('Configuration'); ?></a>
                            <div id="demo" class="collapse">
                                <ul class="list-unstyled">
                                    <li><a href="users-config-index" style="margin-left:1.5em"><?php echo app('translator')->getFromJson('User management'); ?></a></li>
                                    <li><a href="#" style="margin-left:1.5em">Demander l'avancement</a></li>
                                    <li><a href="#" style="margin-left:1.5em">Classifications</a></li>
                                </ul>
                            </div>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </aside>
    <!-- ===== Left-Sidebar-End ===== -->

