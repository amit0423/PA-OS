 <!-- ===== Global layout when user is logged-in ===== -->
<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <?php echo $__env->make('layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
    <div class="main-wrapper">
        <div class="header">
            <?php echo $__env->make('layouts.topnavbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="sidebar" id="sidebar">
            <?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="page-wrapper">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
    <div class="sidebar-overlay" data-reff="#sidebar"></div>
    <?php echo $__env->yieldContent('customscript'); ?>
    <?php echo $__env->make('layouts.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>