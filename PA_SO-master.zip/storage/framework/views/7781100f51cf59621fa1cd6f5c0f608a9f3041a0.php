<?php $__env->startSection('content'); ?>
			<div class="content container-fluid">
				<div class="row">
					<div class="col-xs-4">
						<h4 class="page-title"><?php echo app('translator')->getFromJson('User management'); ?></h4>
					</div>
					<div class="col-xs-8 text-right m-b-30">
						<a href="create-user" class="btn btn-primary rounded"><i class="fa fa-plus"></i>&nbsp <?php echo app('translator')->getFromJson('New user'); ?> &nbsp</a>
					</div>
				</div>
				<div class="row filter-row">
					<form action="filter-users" method="POST">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<div class="col-sm-3 col-xs-6">  
						<div class="form-group form-focus">
							<label class="control-label"><?php echo app('translator')->getFromJson('Name'); ?></label>
							<?php if($filteroptions['filtername']==''): ?>
								<input name="filtername" value="" type="text" class="form-control floating" />
							<?php else: ?>
								<input name="filtername" value=<?php echo e($filteroptions['filtername']); ?> type="text" class="form-control floating" />
							<?php endif; ?> 
						</div>
					</div>
					<div class="col-sm-3 col-xs-6">
						<div class="form-group form-focus select-focus">
							<label class="control-label"><?php echo app('translator')->getFromJson('Division'); ?></label>
							<select name="filterdivision" class="select floating">
								<?php echo e($filter_value = $filteroptions['filterdivision']); ?>

								<?php if($filter_value=='%'): ?>
									<option value=<?php echo e($filteroptions['filterdivision']); ?>><?php echo app('translator')->getFromJson('Select'); ?> <?php echo app('translator')->getFromJson('Division'); ?></option>
								<?php else: ?>
									<option value=<?php echo e($filteroptions['filterdivision']); ?>><?php echo e($filter_value); ?></option>
									<option value='%'><?php echo app('translator')->getFromJson('Select'); ?> <?php echo app('translator')->getFromJson('Division'); ?></option>
								<?php endif; ?>
								
								 <?php if(count($groups)>0): ?>
									<?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value=<?php echo e($group->value); ?>> <?php echo e($group->value); ?> </option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?> 
							</select>
						</div>
					</div>
					<div class="col-sm-3 col-xs-6"> 
						<div class="form-group form-focus select-focus">
							<label class="control-label"><?php echo app('translator')->getFromJson('Type'); ?></label>
							<select name="filtertype" id="select" class="select floating"> 
								<?php if($filteroptions['filtertype']=='%'): ?>
									<option value=<?php echo e($filteroptions['filtertype']); ?>><?php echo app('translator')->getFromJson('Select'); ?> <?php echo app('translator')->getFromJson('Type'); ?></option>
									<?php if(count($types)>0): ?>
										<?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value=<?php echo e($type->value); ?>> <?php echo e($type->fulltext); ?> </option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								<?php else: ?>
									<option value=<?php echo e($filteroptions['filtertype']); ?>><?php echo e($types[$filteroptions['filtertype']]->fulltext); ?></option>
									<?php if(count($types)>0): ?>
										<?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if($type->value==$filteroptions['filtertype']): ?>
												<option value='%'><?php echo app('translator')->getFromJson('Select'); ?> <?php echo app('translator')->getFromJson('Type'); ?></option>
											<?php else: ?>
												<option value=<?php echo e($type->value); ?>> <?php echo e($type->fulltext); ?> </option>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								<?php endif; ?>
								
							</select>
						</div>
					</div>
					<div class="col-sm-3 col-xs-6">  
						<button type="submit" class="btn btn-success btn-block" id="filter"> <?php echo app('translator')->getFromJson('Filter'); ?> <i class="fa fa-filter" style="font-size:18px;"></i></button>  
					</div>
					</form>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="table-responsive">
							<table id="myTable" class="table table-striped table-hover custom-table datatable">
								<thead>
									<tr>
										<th style="width:12%"><?php echo app('translator')->getFromJson('Name'); ?></th>
										<th><?php echo app('translator')->getFromJson('E-Mail Address'); ?></th>
										<th><?php echo app('translator')->getFromJson('Division'); ?></th>
										<th><?php echo app('translator')->getFromJson('Creation date'); ?></th>
										<th><?php echo app('translator')->getFromJson('Type'); ?></th>
										<th><?php echo app('translator')->getFromJson('Status'); ?></th>
										<th class="text-right"><?php echo app('translator')->getFromJson('Action'); ?></th>
									</tr>
								</thead>
								<tbody>
								<?php if(count($users)>0): ?>
									<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php echo e($permission = ""); ?>

										<?php if($user->assign_right == 1 && $user->delegate_right == 1): ?>
											<?php ($permission = 'Assigner et déléguer'); ?>
										<?php elseif($user->assign_right == 1 && $user->delegate_right == 0): ?>
											<?php ($permission = 'Assigner'); ?>
										<?php elseif($user->assign_right == 0 && $user->delegate_right == 1): ?>
											<?php ($permission = ('Déléguer')); ?>
										<?php endif; ?>

										<?php echo e($label = ''); ?>

										<?php if($user->is_permission == 1): ?>
											<?php ($label = 'danger'); ?>
										<?php elseif($user->is_permission == 2): ?>
											<?php ($label = 'info'); ?>
										<?php else: ?>
											<?php ($label = 'success'); ?>
										<?php endif; ?>

										<?php echo e($status = ''); ?>

										<?php echo e($status_label = ''); ?>

										<?php echo e($change_status = ''); ?>

										<?php if($user->status == 0): ?>
											<?php ($status = __('Inactive')); ?>
											<?php ($change_status = __('Activate')); ?>
											<?php ($status_label = 'danger'); ?>
										<?php else: ?>
											<?php ($status = __('Active')); ?>
											<?php ($change_status = __('Deactivate')); ?>
											<?php ($status_label = 'info'); ?>
										<?php endif; ?>
									
										<tr>
											<td>
												<h2><?php echo e($user->name); ?><span><?php echo e($permission); ?></span></h2>
											</td>
											<td><?php echo e($user->email); ?></td>
											<td><?php echo e($user->group); ?></td>
											<td value=<?php echo e($user->created_at); ?>> <?php echo e(date_format($user->created_at, "Y/m/d")); ?></td>
											<td><span class="label label-<?php echo e($label); ?>-border"><?php echo e($types[$user->is_permission]->fulltext); ?></span></td>
											<td><span class="label label-<?php echo e($status_label); ?>-border"><?php echo e($status); ?></span></td>
											<td class="text-right">
												<div class="dropdown">
													<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
													<ul class="dropdown-menu pull-right">
														<li><a href="edit-user-<?php echo e($user->id); ?>" name="edit-user"><i class="fa fa-pencil m-r-5"> </i><?php echo app('translator')->getFromJson('Edit'); ?></a></li>
														<li><a href="change-status-user-<?php echo e($user->id); ?>" name="change-status-user"><i class="fa fa-group m-r-5"> </i><?php echo e($change_status); ?></a></li>
														<li><a href="delete-user-<?php echo e($user->id); ?>" name="delete-user"><i class="fa fa-eraser m-r-5"> </i><?php echo app('translator')->getFromJson('Delete'); ?></a></li>
													</ul>
												</div>
											</td>
										</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
			<div id="delete_user" class="modal custom-modal fade" role="dialog">
				<div class="modal-dialog">
					<div class="modal-content modal-md">
						<div class="modal-header">
							<h4 class="modal-title"><?php echo app('translator')->getFromJson('Delete'); ?> <?php echo app('translator')->getFromJson('user'); ?></h4>
						</div>
					</div>
				</div>
			</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customscript'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>