<?php
namespace App\Repositories\Exceptions;

use Exception;

/**
 * Class RepositoryException
 * @package App\Repository\Exceptions
 */
class RepositoryException extends Exception
{

}
