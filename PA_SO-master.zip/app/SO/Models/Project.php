<?php

namespace App\SO\Models;

use App\SO\Helpers\Uuids as Uuids;
use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    //
}
